## 数据集目录
新闻分类数据集  
包含"体育、科技、娱乐、家居、时政、财经、房产、游戏、时尚、教育"十个类别，其中train文件50000条，val5000条，test10000条。
链接：https://pan.baidu.com/s/1Ej92nFjZwKRnhvCVY-YVXA 
提取码：8y27
