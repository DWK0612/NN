# -*- coding: utf-8 -*-

from .CNN import CNN, CNNConfig
#from .BiLSTM import BiLSTM, BiLSTMConfig
#from .BiLSTMCNN import BiLSTMCNN, BiLSTMCNNConfig
#from .BiLSTMATTCNN import BiLSTMATTCNN, BiLSTMATTCNNConfig
#from .BERT import BERT, BERTConfig